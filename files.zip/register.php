<?php session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>რეგისტრაცია</title>
		<style>
::-webkit-scrollbar {
  height: 10px;
  width: 10px;
  border: 1px solid #ffffff;
}
::-webkit-scrollbar-thumb {
  background: #eeeeee; 
  border-radius: 10px 10px 10px 10px;
}
::-webkit-scrollbar-thumb:hover {
  background: #eeeeee;
  border-radius: 10px 10px 10px 10px;
} 
select {
  width: 100%;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #eeeeee;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #eeeeee;
  border-radius: 4px;
  background-color: #f8f8f8;
  border-left: 5px solid grey;
  resize: none;
}
input[type=password] {
  width: 100%;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #eeeeee;
  border-radius: 4px;
  background-color: #f8f8f8;
  border-left: 5px solid grey;
  resize: none;
}
.logo {
	border-radius: 10px 10px 10px 10px; background-color: #ffffff;
}
a {
	border-radius: 10px 10px 10px 10px; background-color: #f3f3f3;
}
html {
	background-color: #efffef;
}
	</style>
    <script type="text/javascript">
        function tog_usr_change() { document.getElementById('usr').style.display = 'table'; 
        document.getElementById('chng_btn').style.display = 'none'; }
    </script>
  </head>
  <body alink="#6666cc" bgcolor="#fcfcfc" link="#6666cc" text="#000000"
    vlink="#6666cc">
 <?php
 
 include 'std.php';
 
$goal = 'view';

date_default_timezone_set('Asia/Tbilisi');

if (isset($_GET['post_register']))  $goal = 'post_register';
else $goal = "view";

$msg = 'აირჩიეთ თქვენი მომხმარებლის სახელი და პაროლი (სიმბოლოები ავტომატურად გაუქმდება).';

if ($goal == 'post_register')
{
    $usrs = array(); $usrs_names = array(); $usrs_passes = array(); $usrs_perms = array(); 
    load_users($usrs, $usrs_names, $usrs_passes, $usrs_perms);
    $req_usr = '';
    $req_pass = '';
    $req_pass2 = '';
    if (isset($_POST['usr'])) $req_usr = preg_replace("/[^a-zA-Zა-ჰ0-9]+/", "", trim($_POST['usr']));
    if (isset($_POST['psw'])) $req_pass = preg_replace("/[^a-zA-Zა-ჰ0-9]+/", "", trim($_POST['psw']));
    if (isset($_POST['psw2'])) $req_pass2 = preg_replace("/[^a-zA-Zა-ჰ0-9]+/", "", trim($_POST['psw2']));
    $f = array_search($req_usr, $usrs_names);
    while ($f !== false && trim($_POST['bad']) == 'auto')
    {
            $req_usr .= '0';
            $f = array_search($req_usr, $usrs_names);
    }

    if ($f === false && $req_pass == $req_pass2 && isset($_POST['conditions']))
    {
        $usrs[] = $usrs[count($usrs) - 1] + 1;
        $usrs_names[] = $req_usr;
        $usrs_passes[] = $req_pass;
    
        if ($_POST['type'] == '2')
            $usrs_perms[] = explode(' ', "topic_add post_add");
        else if ($_POST['type'] == '1')
            $usrs_perms[] = explode(' ', "post_add");
        else
            $usrs_perms[] = explode(' ', "/");
        
        $outp = '';
        for ($i = 0; $i < count($usrs); ++ $i)
        {
            $outp.=$usrs[$i]."\n".$usrs_names[$i]."\n".$usrs_passes[$i]."\n";
            $outp.=implode(' ', $usrs_perms[$i])."\n";
        }
    
        $fh = file_or_die("usr.txt", "w");
        fwrite($fh, $outp);
        fclose($fh);
        
        $msg = "მომხმარებელი $req_usr რეგისტრირებულია. გადადით მთავარ გვერძზე და გაიარეთ ავტორიზაცია - <a href='index.php'>მთავარი გვერდი</a>.";
    }
    else
        $msg = "სცადეთ ხელახლა.";

}

 ?>
    
    
    <table style="margin-top: 50px;" align="center" bgcolor="#ffffff"
      border="0" cellpadding="15" cellspacing="10" width="1100" style="width:100%; border:1px solid; border-color:#fafafa;">
      <tbody>
        <tr>
          <td colspan="3" rowspan="1" height="1" valign="top">
<a href='/'><img class="logo" src='logo.gif' alt='georgia.eu.org' /></a>
          </td>
        </tr>
        <tr>
          <td align="right" valign="top" width="220px" style="border:1px solid; border-right:1px solid; border-color:#f1f1f1;"><div id="" style="overflow:scroll; height:500px;">
		    <br />
            დარეგისტრირებით შეგიძლიათ თემების გახსნა, პასუხების დაწერა და საკუთარი პოსტების რედაქტირება (მაგრამ არა წაშლა).
			<hr style="width:100%; border:1px solid; border-color:#fafafa;">
		  <b>ფორუმის წესები!</b><br />
1. ფორუმში აკრძალულია თანაფორუმელის შეურაწყოფა.<br />
2. აკრძალულია უცენზურო სიტყვების გამოყენება.<br />
3. აკრძალულია ფორუმში სპამი და ფლუდი (flood and spam).
            <br />
            
          </div></td>
          <td style="border:1px dotted; border-color:#00ffff;" align="left" valign="top"><div id="" style="overflow:scroll; height:500px;">
         
            <hr style="width:100%; border:1px solid; border-color:#fafafa;">
            
            <form align="center" style="font-size:small;" action="?post_register" method="post">
                 <?php echo $msg; ?><br /><br />
                 <input type="text" name="usr" placeholder="მომხმარებელი" maxlength="16" required> <br />
                 <input type="password" name="psw" placeholder="პაროლი" maxlength="30" required> <br />
                 <input type="password" name="psw2" placeholder="გაიმეორეთ პაროლი" maxlength="30" required> <br />
                 <br /><select name="type">
                        <option value="0">წაკითხვის უფლება მხოლოდ</option>
                        <option value="1">გამოხმაურების უფლება მხოლოდ</option>
                        <option value="2" selected>მომხმარებლის ყველა უფლება</option>
                        </select>
                 <br /><br />
                 <b>მომხმარებელი თუ დაკავებულია </b><br /><input type="radio" name="bad" value="return" checked>მონაცემების ახლიდან შეყვანა<br />
                <input type="radio" name="bad" value="auto">ავტომატურად შეირჩეს სხვა სახელი

                <br /><br />
                 <input type="checkbox" name="conditions" required> <b>ვეთანხმები წესებს</b> (წავიკითხე წესები...)


               <br /><br />
            <button type="submit" style="border-radius: 10px 10px 10px 10px; background-color: #f3f3f3;">რეგისტრაცია</button>
            </form>
            
            <br />
          </div></td>
          <td align="left" valign="top" width="220px" style="border:1px solid; border-color:#f1f1f1;"><div id="" style="overflow:scroll; height:500px;">
            <b>პლატფორმა</b><br />
            ბრაუზერი: <?php echo $_SERVER['HTTP_USER_AGENT'].'<br />'; ?><br />
        	<hr style="width:100%; border:1px solid; border-color:#fafafa;">
		  <b>ფორუმის შესახებ</b><br />
ჩვენი ფორუმი გახლავთ საქართველოს ფორუმი, ფორუმში მონაწილეობა შეუძლიათ მომხმარებლებს საქართველოს ნებისმიერი კუთხიდან, ფორუმში განიხილება ნებისმიერი საინტერესო თემა.   
		   <br />
          </div></td>
        </tr>
        <tr>
          <td colspan="3" rowspan="1" height="50" align="center"
            valign="bottom"><font color="#666666"><a
                    href="/">მთავარი გვერდი</a></font><br />
          </td>
        </tr>
      </tbody>
    </table>
    <br />
  </body>
</html>
