<?php
 
 const DIR = 'data/';
 
 function ocisti_string($w)
 {
     return str_replace(array("\n", "\r"), '', trim(nl2br(strip_tags($w))));
}

 function vrati_nl($w)
 {
    $breaks = array("<br />","<br>","<br/>");  
     return str_ireplace($breaks, "\r\n", $w);  
 }

 function check_file_r($path)
 {
     $path = DIR.$path;
     if (file_exists($path))  if (is_readable($path))  return true;
    return false;
}

function check_file($path)
 {
     $path = DIR.$path;
     if (file_exists($path))  if (is_readable($path))  if ( is_writable($path))  return true;
    return false;
}

 function read_file_or_die($path)
 {
     if (check_file_r($path)) return fopen(DIR.$path, "r");
     echo "პრობლემა არის ფორუმის მონაცემების ჩატვირთვისას ან დაზიანებული არის მონაცემები <br />";
     debug_print_backtrace();
     exit(-1); 
}

function file_or_die($path, $how)
 {
     if (check_file($path)) return fopen(DIR.$path, $how);
     echo "პრობლემა არის ფორუმის მონაცემების ჩატვირთვისას ან დაზიანებული არის მონაცემები <br />";
     debug_print_backtrace();
     exit(-1); 
}

function load_users(&$usrs , &$usrs_names, &$usrs_passes, &$usrs_perms)
{
    $fh = read_file_or_die("usr.txt");
    while (($usr = fgets($fh, 4096)) !== false) 
    {   
        $usr_id = trim($usr);
        if (!is_numeric($usr_id))
                break;
                
        $usr_name = trim(fgets($fh, 4096));
        $usr_pass = trim(fgets($fh, 4096));
        $usr_perms = explode(' ', trim(fgets($fh, 4096)));
        
        $usrs[] = $usr_id;
        $usrs_names[] = $usr_name;
        $usrs_passes[] = $usr_pass;
        $usrs_perms[] = $usr_perms;
    }
    fclose($fh);
}

?>