<?

$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "admin"
&& $pass == "12345678")
{
@unlink("ban/ips.txt");

print "<script language=JavaScript>window.alert('ბრძანება შესრულებულია! ყველა დაბლოკილი IP მისამართი წაიშალა, გასუფთავდა ბლოკირებულთა ბაზა.');</script>";

print "<script language=\"JavaScript\">
<!-- 
if (navigator.appName == \"Netscape\") window.location.href = \"index.php\";
else if (navigator.appName == \"Microsoft Internet Explorer\") window.location.href = \"index.php\";
else window.location.href = \"index.php\";
// -->
</script>";
}
else
{
    if(isset($_POST))
    {?>
            <center>
            <form method="POST" action="unban.php">
            <br>ადმინისტრატორი<br> <input type="text" name="user"></input>
            <br>პაროლი<br> <input type="password" name="pass"></input><br/>
            <input type="submit" name="submit" value="IP ბლოკის მოხსნა"></input>
            </form>
            </center>
    <?}
}

?>
